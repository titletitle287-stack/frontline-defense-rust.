use wasm_bindgen::prelude::*;
use wasm_bindgen::JsCast;
use web_sys::{CanvasRenderingContext2d, HtmlCanvasElement, PointerEvent};
use std::cell::RefCell;
use std::rc::Rc;

#[derive(Clone)]
struct Enemy { x:f64, y:f64, seg:usize, hp:f64, max:f64, speed:f64, slow:f64, reward:i32, armor:bool }
#[derive(Clone)]
struct Tower { x:f64, y:f64, kind:usize, level:u32, damage:f64, range:f64, rate:f64, cooldown:f64, angle:f64, upgrade:i32 }
#[derive(Clone)]
struct Bullet { x:f64, y:f64, target:usize, damage:f64, kind:usize, speed:f64 }

struct Game {
    ctx: CanvasRenderingContext2d, canvas: HtmlCanvasElement,
    money:i32, base:i32, wave:u32, enemies:Vec<Enemy>, towers:Vec<Tower>, bullets:Vec<Bullet>,
    build:usize, selected:Option<usize>, running:bool, paused:bool, over:bool,
    spawn:i32, spawn_timer:f64, speed:f64, last:f64, message:String,
}
const PATH:[(f64,f64);8]=[(-20.,155.),(210.,155.),(210.,355.),(475.,355.),(475.,190.),(735.,190.),(735.,455.),(980.,455.)];
const SPOTS:[(f64,f64);10]=[(115.,245.),(300.,105.),(315.,435.),(555.,285.),(625.,105.),(820.,290.),(850.,525.),(90.,430.),(390.,260.),(660.,520.)];
const COST:[i32;3]=[70,115,90];
const RANGE:[f64;3]=[145.,190.,135.];
const DAMAGE:[f64;3]=[12.,38.,3.];
const RATE:[f64;3]=[0.42,1.25,0.7];
const UPGRADE:[i32;3]=[55,85,70];
const COLORS:[&str;3]=["#e5bd63","#e27e58","#70c9d4"];

fn dist(x:f64,y:f64,a:f64,b:f64)->f64 { ((x-a).powi(2)+(y-b).powi(2)).sqrt() }
fn set_text(id:&str, value:String) {
    if let Some(el)=web_sys::window().unwrap().document().unwrap().get_element_by_id(id) { el.set_text_content(Some(&value)); }
}
impl Game {
 fn ui(&self) {
    set_text("money",self.money.to_string()); set_text("hp",self.base.to_string());
    set_text("wave",self.wave.to_string()); set_text("enemies",(self.enemies.len()+self.spawn.max(0) as usize).to_string());
    set_text("message",self.message.clone());
    set_text("towerInfo", if let Some(i)=self.selected.filter(|i|*i<self.towers.len()) {
      let t=&self.towers[i]; format!("Башня уровня {} · Урон {} · Радиус {} · Улучшение {} кредитов",t.level,t.damage as i32,t.range,t.upgrade)
    } else {"Нажми на установленную башню, чтобы посмотреть параметры.".into()});
    if let Some(el)=web_sys::window().unwrap().document().unwrap().get_element_by_id("upgrade") {
      let _=el.set_attribute("disabled", if self.selected.map_or(true,|i|i>=self.towers.len() || self.money<self.towers[i].upgrade) {"true"} else {"false"});
    }
    if let Some(el)=web_sys::window().unwrap().document().unwrap().get_element_by_id("sell") {
      let _=el.set_attribute("disabled", if self.selected.map_or(true,|i|i>=self.towers.len()) {"true"} else {"false"});
    }
 }
 fn draw(&self) {
    let c=&self.ctx; c.clear_rect(0.,0.,960.,600.);
    c.set_fill_style_str("#34483b"); c.fill_rect(0.,0.,960.,600.);
    for i in 0.0.90 { let x=((i*137)%960) as f64; let y=((i*83)%600) as f64;
      c.set_fill_style_str(if i%3==0 {"#4b6248"} else {"#405744"}); c.begin_path(); let _=c.arc(x,y,5.+(i%5) as f64,0.,std::f64::consts::TAU); c.fill(); }
    c.set_line_cap("round"); c.set_line_join("round"); c.set_stroke_style_str("#776f5d"); c.set_line_width(78.);
    c.begin_path(); for (i,(x,y)) in PATH.iter().enumerate(){if i==0 {c.move_to(*x,*y)}else{c.line_to(*x,*y)}} c.stroke();
    c.set_stroke_style_str("#9b9078"); c.set_line_width(2.); c.set_line_dash(&js_sys::Array::of2(&14.into(),&17.into()).into()).ok();
    c.begin_path(); for (i,(x,y)) in PATH.iter().enumerate(){if i==0 {c.move_to(*x,*y)}else{c.line_to(*x,*y)}} c.stroke(); c.set_line_dash(&js_sys::Array::new().into()).ok();
    c.set_fill_style_str("#273744"); c.fill_rect(875.,405.,66.,95.); c.set_fill_style_str("#d2b36a"); c.fill_rect(889.,420.,38.,65.);
    c.set_fill_style_str("#e9e0c9"); c.set_font("bold 13px sans-serif"); let _=c.fill_text("БАЗА",887.,398.);
    for (x,y) in SPOTS { c.set_stroke_style_str("#c3c9ad88"); c.set_line_width(2.); c.begin_path(); let _=c.arc(x,y,19.,0.,std::f64::consts::TAU); c.stroke(); }
    for (i,t) in self.towers.iter().enumerate() {
      if self.selected==Some(i) { c.set_fill_style_str("#ffffff18"); c.begin_path(); let _=c.arc(t.x,t.y,t.range,0.,std::f64::consts::TAU); c.fill(); }
      c.set_fill_style_str("#18232b"); c.begin_path(); let _=c.arc(t.x,t.y,18.,0.,std::f64::consts::TAU); c.fill();
      c.set_fill_style_str(COLORS[t.kind]); c.begin_path(); let _=c.arc(t.x,t.y,13.,0.,std::f64::consts::TAU); c.fill();
      c.set_stroke_style_str("#18232b"); c.set_line_width(4.); c.begin_path(); c.move_to(t.x,t.y); c.line_to(t.x+t.angle.cos()*19.,t.y+t.angle.sin()*19.); c.stroke();
      c.set_fill_style_str("#f1e8cf"); c.set_font("11px sans-serif"); let _=c.fill_text(&format!("У{}",t.level),t.x-8.,t.y+31.);
    }
    for e in &self.enemies {
      c.set_fill_style_str(if e.slow>0. {"#8bdde5"} else {"#bd6254"}); c.begin_path(); let _=c.arc(e.x,e.y,if e.armor {15.} else {11.},0.,std::f64::consts::TAU); c.fill();
      c.set_fill_style_str("#202020"); c.fill_rect(e.x-15.,e.y-24.,30.,4.); c.set_fill_style_str("#83c978"); c.fill_rect(e.x-15.,e.y-24.,30.*(e.hp/e.max).max(0.),4.);
    }
    for b in &self.bullets { c.set_fill_style_str(COLORS[b.kind]); c.begin_path(); let _=c.arc(b.x,b.y,4.,0.,std::f64::consts::TAU); c.fill(); }
    if !self.running && !self.over { c.set_fill_style_str("#fff"); c.set_font("bold 19px sans-serif"); let _=c.fill_text("ЗОНА ОБОРОНЫ",22.,34.); }
 }
 fn start_wave(&mut self){if self.running||self.over{return} self.wave+=1; self.spawn=7+(self.wave as i32)*2; self.spawn_timer=0.; self.running=true; self.message=format!("Волна {}: противник приближается!",self.wave);}
 fn reset(&mut self){self.money=220;self.base=20;self.wave=0;self.enemies.clear();self.towers.clear();self.bullets.clear();self.selected=None;self.running=false;self.paused=false;self.over=false;self.spawn=0;self.speed=1.;self.message="Подготовь оборону и запусти первую волну.".into(); if let Some(el)=web_sys::window().unwrap().document().unwrap().get_element_by_id("overlay"){el.set_class_name("");}}
 fn click(&mut self,x:f64,y:f64) {
    if let Some(i)=self.towers.iter().rposition(|t|dist(t.x,t.y,x,y)<22.) {self.selected=Some(i);self.ui();return}
    self.selected=None;
    if !self.running&&!self.over {
      if let Some((sx,sy))=SPOTS.iter().find(|(sx,sy)|dist(*sx,*sy,x,y)<23.) {
        if self.towers.iter().any(|t|dist(t.x,t.y,*sx,*sy)<28.) {self.message="Это место уже занято.".into();}
        else if self.money>=COST[self.build] {self.money-=COST[self.build];self.towers.push(Tower{x:*sx,y:*sy,kind:self.build,level:1,damage:DAMAGE[self.build],range:RANGE[self.build],rate:RATE[self.build],cooldown:0.2,angle:-1.57,upgrade:UPGRADE[self.build]});self.message="Башня построена.".into();}
        else {self.message="Недостаточно кредитов.".into();}
      }
    } self.ui();
 }
 fn tick(&mut self,dt:f64) {
   if !self.running||self.paused||self.over{return}
   if self.spawn>0 {self.spawn_timer-=dt;if self.spawn_timer<=0. {let armor=self.wave%5==0;let hp=55.+self.wave as f64*17.+if armor {100.}else{0.};self.enemies.push(Enemy{x:PATH[0]0.0,y:PATH[0]0.1,seg:0,hp,max:hp,speed:(if armor {43.}else{57.})+(self.wave.min(15) as f64)*1.7,slow:0.,reward:if armor {28}else{12},armor});self.spawn-=1;self.spawn_timer=(1.05-self.wave as f64*0.018).max(0.42);}}
   let mut leaked=0;
   for e in &mut self.enemies {let mut rem=e.speed*(if e.slow>0. {0.48}else{1.})*dt;e.slow=(e.slow-dt).max(0.);
     while rem>0. && e.seg<PATH.len()-1 {let (tx,ty)=PATH[e.seg+1];let d=dist(e.x,e.y,tx,ty);if d<=rem {e.x=tx;e.y=ty;rem-=d;e.seg+=1;}else{e.x+=(tx-e.x)/d*rem;e.y+=(ty-e.y)/d*rem;rem=0.;}}
     if e.seg>=PATH.len()-1 {leaked+=1;}
   }
   self.enemies.retain(|e|e.seg<PATH.len()-1); self.base-=leaked;
   for t in &mut self.towers {t.cooldown-=dt;let target=self.enemies.iter().enumerate().filter(|(_,e)|dist(t.x,t.y,e.x,e.y)<=t.range).max_by_key(|(_,e)|e.seg).map(|(i,_)|i);
     if let Some(i)=target {let e=&self.enemies[i];t.angle=(e.y-t.y).atan2(e.x-t.x);if t.cooldown<=0. {self.bullets.push(Bullet{x:t.x+t.angle.cos()*18.,y:t.y+t.angle.sin()*18.,target:i,damage:t.damage,kind:t.kind,speed:if t.kind==1 {390.}else{470.}});t.cooldown=t.rate;}}
   }
   let mut dead=Vec::new();let mut rewards=0;
   for b in &mut self.bullets {if b.target>=self.enemies.len(){continue}let e=&mut self.enemies[b.target];let d=dist(b.x,b.y,e.x,e.y);let step=b.speed*dt;
     if d<=step+11. {e.hp-=b.damage;if b.kind==2 {e.slow=1.7}if e.hp<=0. {dead.push(b.target);rewards+=e.reward;}}
     else if d>0. {b.x+=(e.x-b.x)/d*step;b.y+=(e.y-b.y)/d*step;}
   }
   dead.sort_unstable();dead.dedup();for i in dead.into_iter().rev(){if i<self.enemies.len(){self.enemies.remove(i);}}
   self.money+=rewards;self.bullets.retain(|b|b.target<self.enemies.len());
   if self.base<=0 {self.base=0;self.over=true;self.running=false;self.message=format!("База потеряна! Ты продержался до волны {}.",self.wave);if let Some(el)=web_sys::window().unwrap().document().unwrap().get_element_by_id("overlay"){el.set_class_name("show");}set_text("overlayText",self.message.clone());}
   if self.running&&self.spawn==0&&self.enemies.is_empty(){self.running=false;self.money+=35+self.wave as i32*5;self.message=format!("Волна {} отражена! Бонус: {} кредитов.",self.wave,35+self.wave as i32*5);}
   self.ui();
 }
}
#[wasm_bindgen(start)]
pub fn start() -> Result<(),JsValue> {
 let window=web_sys::window().unwrap();let document=window.document().unwrap();
 let canvas:HtmlCanvasElement=document.get_element_by_id("game").unwrap().dyn_into()?;
 let ctx:CanvasRenderingContext2d=canvas.get_context("2d")?.unwrap().dyn_into()?;
 let game=Rc::new(RefCell::new(Game{ctx,canvas:canvas.clone(),money:220,base:20,wave:0,enemies:vec![],towers:vec![],bullets:vec![],build:0,selected:None,running:false,paused:false,over:false,spawn:0,spawn_timer:0.,speed:1.,last:0.,message:"Подготовь оборону и запусти первую волну.".into()}));
 {
 let g=game.clone();let cb=Closure::<dyn FnMut(PointerEvent)>::new(move |e|{let r=g.borrow().canvas.get_bounding_client_rect();let x=(e.client_x() as f64-r.left())*960./r.width();let y=(e.client_y() as f64-r.top())*600./r.height();g.borrow_mut().click(x,y);});
 canvas.add_event_listener_with_callback("pointerdown",cb.as_ref().unchecked_ref())?;cb.forget();
 }
 let bind=|id:&str, f:Box<dyn FnMut(&mut Game)>| -> Result<(),JsValue> {
   let el=document.get_element_by_id(id).unwrap();let g=game.clone();let mut fun=f;
   let cb=Closure::<dyn FnMut(web_sys::Event)>::new(move |_|fun(&mut g.borrow_mut()));
   el.add_event_listener_with_callback("click",cb.as_ref().unchecked_ref())?;cb.forget();Ok(())
 };
 bind("startWave",Box::new(|g|g.start_wave()))?;
 bind("pause",Box::new(|g|{g.paused=!g.paused;set_text("pause",if g.paused {"Продолжить".into()}else{"Пауза".into()});}))?;
 bind("speed",Box::new(|g|{g.speed=if g.speed==1. {2.}else if g.speed==2. {3.}else{1.};set_text("speed",format!("Скорость: {}×",g.speed));}))?;
 bind("restart",Box::new(|g|g.reset()))?;
 bind("upgrade",Box::new(|g|{if let Some(i)=g.selected {if i<g.towers.len()&&g.money>=g.towers[i].upgrade {let cost=g.towers[i].upgrade;g.money-=cost;let t=&mut g.towers[i];t.level+=1;t.damage*=1.55;t.range+=12.;t.rate*=0.88;t.upgrade=(t.upgrade as f64*1.65) as i32;g.message="Башня модернизирована.".into();}}}))?;
 bind("sell",Box::new(|g|{if let Some(i)=g.selected {if i<g.towers.len(){let t=g.towers.remove(i);g.money+=(COST[t.kind] as f64*0.55+t.level as f64*20.) as i32;g.selected=None;g.message="Башня продана.".into();}}}))?;
 for (id,k) in [("gun",0),("cannon",1),("slow",2)] {let g=game.clone();let el=document.query_selector(&format!("[data-tower='{}']",id))?.unwrap();let cb=Closure::<dyn FnMut(web_sys::Event)>::new(move |_|{let mut s=g.borrow_mut();s.build=k;s.selected=None;s.ui();});el.add_event_listener_with_callback("click",cb.as_ref().unchecked_ref())?;cb.forget();}
 let raf=Rc::new(RefCell::new(None));let raf2=raf.clone();let g=game.clone();
 *raf2.borrow_mut()=Some(Closure::<dyn FnMut(f64)>::new(move |ts:f64|{let mut s=g.borrow_mut();let dt=if s.last==0. {0.}else{((ts-s.last)/1000.).min(0.04)*s.speed};s.last=ts;s.tick(dt);s.draw();drop(s);web_sys::window().unwrap().request_animation_frame(raf.borrow().as_ref().unwrap().as_ref().unchecked_ref()).unwrap();}));
 web_sys::window().unwrap().request_animation_frame(raf2.borrow().as_ref().unwrap().as_ref().unchecked_ref())?;
 game.borrow().ui();Ok(())
}
