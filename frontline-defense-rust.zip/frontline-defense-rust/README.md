# Frontline Defense — Rust + WebAssembly

Это браузерная версия игры: игровая логика написана на Rust и компилируется в WebAssembly (WASM). HTML нужен только для оболочки и кнопок.

## Публикация на GitHub Pages
1. Создай публичный репозиторий `frontline-defense`.
2. Загрузи в корень репозитория содержимое этого проекта: `Cargo.toml`, `index.html`, `src/` и `.github/`.
3. Открой Settings → Pages. В разделе Build and deployment выбери **GitHub Actions**.
4. Открой вкладку Actions и дождись завершения workflow **Build and deploy Rust game**.
5. После успешной сборки открой Settings → Pages → Visit site.

Сборка происходит на серверах GitHub: устанавливать Rust на телефон не нужно.

## Управление
Выбери башню, коснись одной из площадок рядом с дорогой, затем нажми «Начать волну». Башни можно выбирать, улучшать и продавать.
